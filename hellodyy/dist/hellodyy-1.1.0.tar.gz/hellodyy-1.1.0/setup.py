from distutils.core import setup
setup(
  name = 'hellodyy',
  version = '1.1.0',
  py_modules = ['hellodyy'],
  author = 'dyy',
  author_email = 'gtfx0209@gamil.com',
  url = 'http://dyy.im',
  description = 'hello python by dyy'

)